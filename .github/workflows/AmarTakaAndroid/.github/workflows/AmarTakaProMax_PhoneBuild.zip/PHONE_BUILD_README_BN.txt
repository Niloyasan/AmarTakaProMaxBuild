আমার টাকা Pro Max — শুধু Android ফোন দিয়ে APK বানানোর পদ্ধতি

এই প্যাকেজে Android project ZIP আছে। APK সরাসরি তৈরি করা নেই। GitHub Actions দিয়ে ক্লাউডে build করতে হবে। GitHub account এবং ইন্টারনেট লাগবে। GitHub Actions-এর quota/availability account অনুযায়ী ভিন্ন হতে পারে।

ধাপ ১: ফোনের ব্রাউজারে https://github.com খুলে সাইন ইন/অ্যাকাউন্ট তৈরি করুন।
ধাপ ২: New repository তৈরি করুন; নাম দিন AmarTakaProMaxBuild। Public রাখলে সেটআপ সহজ, তবে কোড প্রকাশ্য হবে। ব্যক্তিগত রাখতে চাইলে Private নির্বাচন করুন।
ধাপ ৩: রিপোজিটরিতে Add file > Create new file নির্বাচন করুন। ফাইলের নাম লিখুন:
.github/workflows/build-apk.yml
ধাপ ৪: এই প্যাকেজের AmarTakaAndroid/.github/workflows/build-apk.yml ফাইলের সম্পূর্ণ লেখা সেখানে paste করে Commit করুন।
ধাপ ৫: আবার Add file > Upload files নির্বাচন করে AmarTakaProMax_AndroidStudio_Project.zip ফাইলটি আপলোড করুন। ফাইলের নাম ঠিক এটাই রাখুন। Commit করুন।
ধাপ ৬: Actions tab খুলুন। “Build Amar Taka Pro Max APK” workflow চালু/চলছে কি না দেখুন। প্রথম build কয়েক মিনিট লাগতে পারে। লাল ব্যর্থতা দেখালে সেটি সফল হয়নি—লগ দেখে ঠিক করতে হবে।
ধাপ ৭: সফল হলে workflow run খুলুন, নিচে Artifacts থেকে Amar-Taka-Pro-Max-APK ডাউনলোড করুন। ZIP খুলে app-debug.apk বের করুন।
ধাপ ৮: APK-তে চাপ দিয়ে Android-এর নির্দেশনা অনুযায়ী install অনুমতি দিন। শুধু নিজের তৈরি করা/বিশ্বস্ত APK ইনস্টল করুন।

গুরুত্বপূর্ণ:
- এই পদ্ধতি ক্লাউডে APK বানায়; ফোনে Android Studio লাগবে না।
- APK build হওয়া এখনও বাস্তবে নিশ্চিত নয়; প্রথমবার build error হলে Actions log প্রয়োজন হবে।
- APK চালুর আগে পুরোনো HTML অ্যাপ থেকে JSON backup নিন। APK-এর ডেটা আলাদা থাকবে; JSON backup import করতে হবে।
- হিসাবের ডেটা ব্যক্তিগত। Public repository-তে নিজের বাস্তব হিসাব, backup JSON, password বা গোপন তথ্য কখনো আপলোড করবেন না।
- APK install করার আগে backup রাখুন।
